#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gantt_chart_generator.py - 日本語ガントチャート生成ツール
=========================================================
日本の祝日・土日に対応した業務用ガントチャート（.xlsx）を生成します。

使い方:
  python gantt_chart_generator.py                          # config.json を読み込んで生成
  python gantt_chart_generator.py -c myproject.json        # 任意の設定ファイルを指定
  python gantt_chart_generator.py -o output.xlsx           # 出力ファイル名を指定
  python gantt_chart_generator.py --year 2027              # 祝日の年を指定
  python gantt_chart_generator.py --sample                 # サンプル設定ファイルを生成

必要ライブラリ: openpyxl (pip install openpyxl)
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

# ==================================================
#  日本の祝日データベース
# ==================================================
HOLIDAYS: dict[int, dict[date, str]] = {
    2025: {
        date(2025,  1,  1): "元日",
        date(2025,  1, 13): "成人の日",
        date(2025,  2, 11): "建国記念の日",
        date(2025,  2, 23): "天皇誕生日",
        date(2025,  2, 24): "振替休日",
        date(2025,  3, 20): "春分の日",
        date(2025,  4, 29): "昭和の日",
        date(2025,  5,  3): "憲法記念日",
        date(2025,  5,  4): "みどりの日",
        date(2025,  5,  5): "こどもの日",
        date(2025,  5,  6): "振替休日",
        date(2025,  7, 21): "海の日",
        date(2025,  8, 11): "山の日",
        date(2025,  9, 15): "敬老の日",
        date(2025,  9, 23): "秋分の日",
        date(2025, 10, 13): "スポーツの日",
        date(2025, 11,  3): "文化の日",
        date(2025, 11, 23): "勤労感謝の日",
        date(2025, 11, 24): "振替休日",
    },
    2026: {
        date(2026,  1,  1): "元日",
        date(2026,  1, 12): "成人の日",
        date(2026,  2, 11): "建国記念の日",
        date(2026,  2, 23): "天皇誕生日",
        date(2026,  3, 20): "春分の日",
        date(2026,  4, 29): "昭和の日",
        date(2026,  5,  3): "憲法記念日",
        date(2026,  5,  4): "みどりの日",
        date(2026,  5,  5): "こどもの日",
        date(2026,  5,  6): "振替休日",
        date(2026,  7, 20): "海の日",
        date(2026,  8, 11): "山の日",
        date(2026,  9, 21): "敬老の日",
        date(2026,  9, 23): "秋分の日",
        date(2026, 10, 12): "スポーツの日",
        date(2026, 11,  3): "文化の日",
        date(2026, 11, 23): "勤労感謝の日",
    },
    2027: {
        date(2027,  1,  1): "元日",
        date(2027,  1, 11): "成人の日",
        date(2027,  2, 11): "建国記念の日",
        date(2027,  2, 23): "天皇誕生日",
        date(2027,  3, 21): "春分の日",
        date(2027,  3, 22): "振替休日",
        date(2027,  4, 29): "昭和の日",
        date(2027,  5,  3): "憲法記念日",
        date(2027,  5,  4): "みどりの日",
        date(2027,  5,  5): "こどもの日",
        date(2027,  7, 19): "海の日",
        date(2027,  8, 11): "山の日",
        date(2027,  9, 20): "敬老の日",
        date(2027,  9, 23): "秋分の日",
        date(2027, 10, 11): "スポーツの日",
        date(2027, 11,  3): "文化の日",
        date(2027, 11, 23): "勤労感謝の日",
    },
}


def get_holidays_for_range(start: date, end: date) -> dict[date, str]:
    result = {}
    for year in range(start.year, end.year + 1):
        if year in HOLIDAYS:
            for d, name in HOLIDAYS[year].items():
                if start <= d <= end:
                    result[d] = name
    return result


def is_holiday(d: date, holidays: dict[date, str]) -> bool:
    return d in holidays


def is_non_working(d: date, holidays: dict[date, str]) -> bool:
    return d.weekday() >= 5 or is_holiday(d, holidays)


def count_working_days(start: date, end: date, holidays: dict[date, str]) -> int:
    count = 0
    d = start
    while d <= end:
        if not is_non_working(d, holidays):
            count += 1
        d += timedelta(days=1)
    return count


# ==================================================
#  カラーパレットとスタイル
# ==================================================
TASK_COLORS = [
    {"bar": "FF4472C4", "light": "FFD6E4F7"},
    {"bar": "FFED7D31", "light": "FFFCE4D0"},
    {"bar": "FF70AD47", "light": "FFD8EDCB"},
    {"bar": "FFFFC000", "light": "FFFFF2CC"},
    {"bar": "FF5B9BD5", "light": "FFD3E8F5"},
    {"bar": "FFFF6699", "light": "FFFFD6E5"},
    {"bar": "FF7030A0", "light": "FFE8D5F5"},
    {"bar": "FF00B0F0", "light": "FFD0EEFB"},
    {"bar": "FF92D050", "light": "FFE2F0D0"},
    {"bar": "FFFF4444", "light": "FFFFD5D5"},
]

STATUS_COLORS = {
    "完了":   {"bg": "FFE2EFDA", "fg": "FF375623"},
    "進行中": {"bg": "FFDCE6F1", "fg": "FF1F4E79"},
    "未着手": {"bg": "FFFFF2CC", "fg": "FF7F6000"},
    "遅延":   {"bg": "FFFCE4EC", "fg": "FFC00000"},
    "中断":   {"bg": "FFE8E8E8", "fg": "FF595959"},
}

PRIORITY_COLORS = {
    "最高": {"bg": "FFFF0000", "fg": "FFFFFFFF"},
    "高":   {"bg": "FFFF6600", "fg": "FFFFFFFF"},
    "中":   {"bg": "FFFFC000", "fg": "FF333333"},
    "低":   {"bg": "FF92D050", "fg": "FF333333"},
}

# Style constants
FONT_NAME   = "Meiryo UI"
HEADER_BG   = "FF1F3864"
HEADER_FG   = "FFFFFFFF"
MONTH_BG    = "FF2F5496"
WEEKEND_BG  = "FFE8E8E8"
HOLIDAY_BG  = "FFFCE4EC"
ROW_EVEN    = "FFFFFFFF"
ROW_ODD     = "FFF5F7FA"
TODAY_RED    = "FFFF0000"
MILESTONE_C = "FFFF4444"
GRIDLINE    = "FFBFBFBF"
MONTH_LINE  = "FF595959"


def _fill(c: str) -> PatternFill:
    if len(c) == 6:
        c = "FF" + c
    return PatternFill("solid", fgColor=c)


def _border(top="thin", bottom="thin", left="thin", right="thin",
            top_c=GRIDLINE, bottom_c=GRIDLINE, left_c=GRIDLINE, right_c=GRIDLINE) -> Border:
    def s(style, color):
        return Side(style=style, color=color) if style else Side(style=None)
    return Border(top=s(top, top_c), bottom=s(bottom, bottom_c),
                  left=s(left, left_c), right=s(right, right_c))


def _std() -> Border:
    return _border()


def _font(size=10, bold=False, color="FF333333", italic=False) -> Font:
    return Font(name=FONT_NAME, size=size, bold=bold, color=color, italic=italic)


def _align(h="center", v="center", wrap=False, indent=0) -> Alignment:
    return Alignment(horizontal=h, vertical=v, wrap_text=wrap, indent=indent)


# ==================================================
#  設定ファイル読み込み
# ==================================================
def load_config(path: str) -> dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)

    tasks = []
    for t in raw.get("tasks", []):
        tasks.append({
            "name":     t["name"],
            "start":    datetime.strptime(t["start"], "%Y-%m-%d").date(),
            "end":      datetime.strptime(t["end"], "%Y-%m-%d").date(),
            "assignee": t.get("assignee", ""),
            "status":   t.get("status", "未着手"),
            "priority": t.get("priority", "中"),
            "progress": t.get("progress", 0),
            "note":     t.get("note", ""),
        })

    return {
        "title": raw.get("title", "プロジェクト工程表"),
        "tasks": tasks,
    }


def generate_sample_config(path: str) -> None:
    sample = {
        "title": "○○システム開発プロジェクト 工程表",
        "tasks": [
            {"name": "要件定義",          "start": "2026-04-01", "end": "2026-04-07",
             "assignee": "田中", "status": "完了",   "priority": "高", "progress": 100,
             "note": "顧客ヒアリング完了"},
            {"name": "基本設計",          "start": "2026-04-06", "end": "2026-04-14",
             "assignee": "鈴木", "status": "進行中", "priority": "高", "progress": 60,
             "note": "DB設計レビュー待ち"},
            {"name": "詳細設計",          "start": "2026-04-13", "end": "2026-04-22",
             "assignee": "佐藤", "status": "未着手", "priority": "中", "progress": 0, "note": ""},
            {"name": "フロントエンド開発", "start": "2026-04-20", "end": "2026-05-01",
             "assignee": "高橋", "status": "未着手", "priority": "高", "progress": 0,
             "note": "React + TypeScript"},
            {"name": "バックエンド開発",   "start": "2026-04-22", "end": "2026-05-08",
             "assignee": "伊藤", "status": "未着手", "priority": "高", "progress": 0,
             "note": "API設計書参照"},
            {"name": "DB構築",            "start": "2026-04-20", "end": "2026-04-28",
             "assignee": "渡辺", "status": "未着手", "priority": "中", "progress": 0,
             "note": "PostgreSQL"},
            {"name": "結合テスト",        "start": "2026-05-07", "end": "2026-05-15",
             "assignee": "山本", "status": "未着手", "priority": "高", "progress": 0,
             "note": "テスト仕様書作成中"},
            {"name": "受入テスト（UAT）",  "start": "2026-05-14", "end": "2026-05-22",
             "assignee": "中村", "status": "未着手", "priority": "高", "progress": 0,
             "note": "顧客参加"},
            {"name": "リリース準備",      "start": "2026-05-21", "end": "2026-05-27",
             "assignee": "田中", "status": "未着手", "priority": "中", "progress": 0,
             "note": "インフラ・ドキュメント"},
            {"name": "★ 本番リリース",    "start": "2026-05-28", "end": "2026-05-28",
             "assignee": "全員", "status": "未着手", "priority": "最高", "progress": 0,
             "note": "マイルストーン"},
        ]
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(sample, f, ensure_ascii=False, indent=2)
    print(f"✅ サンプル設定ファイルを生成しました: {path}")


# ==================================================
#  入力シート
# ==================================================
def create_input_sheet(wb: Workbook, title: str, tasks: list[dict],
                       holidays: dict[date, str]) -> None:
    ws = wb.active
    ws.title = "入力"

    # Title
    ws.merge_cells("A1:K1")
    c = ws["A1"]
    c.value = title
    c.font = _font(18, bold=True, color=HEADER_FG)
    c.fill = _fill(HEADER_BG)
    c.alignment = _align()
    ws.row_dimensions[1].height = 42

    # Sub-header
    ws.merge_cells("A2:K2")
    c = ws["A2"]
    c.value = (f"作成日: {date.today().strftime('%Y年%m月%d日')}　｜　"
               f"タスクを編集後スクリプトを再実行してガントチャートを更新")
    c.font = _font(9, italic=True, color="FF595959")
    c.fill = _fill("FFEEF2FA")
    c.alignment = _align(h="left", wrap=True)
    ws.row_dimensions[2].height = 24
    ws.row_dimensions[3].height = 6

    # Headers
    headers = [
        ("No.",       5),  ("ステータス", 10), ("優先度", 8),
        ("タスク名",   28), ("担当者",    10), ("開始日", 13),
        ("終了日",    13),  ("暦日数",     8), ("稼働日数", 9),
        ("進捗率",     8),  ("備考",      30),
    ]
    HR = 4
    for col, (h, w) in enumerate(headers, start=1):
        c = ws.cell(row=HR, column=col, value=h)
        c.font = _font(9, bold=True, color=HEADER_FG)
        c.fill = _fill(MONTH_BG)
        c.alignment = _align()
        c.border = _std()
        ws.column_dimensions[get_column_letter(col)].width = w
    ws.row_dimensions[HR].height = 24

    # Data rows
    for i, task in enumerate(tasks):
        row = 5 + i
        bg = ROW_EVEN if i % 2 == 0 else ROW_ODD
        fill = _fill(bg)

        def cell(col, value, bold=False, h="center", num_fmt=None,
                 custom_fill=None, fg_color="FF333333"):
            c = ws.cell(row=row, column=col, value=value)
            c.font = _font(9, bold=bold, color=fg_color)
            c.fill = custom_fill or fill
            c.alignment = _align(h=h, indent=1 if h == "left" else 0)
            c.border = _std()
            if num_fmt:
                c.number_format = num_fmt
            return c

        cell(1, i + 1)

        st = task.get("status", "未着手")
        sc = STATUS_COLORS.get(st, STATUS_COLORS["未着手"])
        cell(2, st, bold=True, custom_fill=_fill(sc["bg"]), fg_color=sc["fg"])

        pr = task.get("priority", "中")
        pc = PRIORITY_COLORS.get(pr, PRIORITY_COLORS["中"])
        cell(3, pr, bold=True, custom_fill=_fill(pc["bg"]), fg_color=pc["fg"])

        cell(4, task["name"], bold=True, h="left")
        cell(5, task.get("assignee", ""))
        cell(6, task["start"], num_fmt="YYYY/MM/DD")
        cell(7, task["end"], num_fmt="YYYY/MM/DD")
        cell(8, f"=G{row}-F{row}+1", num_fmt='0"日"')

        wd = count_working_days(task["start"], task["end"], holidays)
        cell(9, wd, num_fmt='0"日"', fg_color="FF2F5496")

        prog = task.get("progress", 0) / 100.0
        c = cell(10, prog, num_fmt="0%")
        if prog >= 1.0:
            c.font = _font(9, bold=True, color="FF375623")
        elif prog > 0:
            c.font = _font(9, bold=True, color="FF1F4E79")

        cell(11, task.get("note", ""), h="left")
        ws.row_dimensions[row].height = 22

    # Total row
    tr = 5 + len(tasks)
    ws.merge_cells(f"A{tr}:G{tr}")
    c = ws.cell(row=tr, column=1, value="合計タスク数 / 完了率")
    c.font = _font(9, bold=True, color=HEADER_FG)
    c.fill = _fill(HEADER_BG)
    c.alignment = _align(h="right", indent=1)
    c.border = _std()
    for col in range(2, 8):
        ws.cell(row=tr, column=col).fill = _fill(HEADER_BG)
        ws.cell(row=tr, column=col).border = _std()

    for col, val, fmt in [
        (8, len(tasks), '0"件"'),
        (9, f"=SUM(I5:I{tr-1})", '0"日"'),
        (10, f"=AVERAGE(J5:J{tr-1})", "0%"),
    ]:
        c = ws.cell(row=tr, column=col, value=val)
        c.font = _font(9, bold=True, color=HEADER_FG)
        c.fill = _fill(HEADER_BG)
        c.alignment = _align()
        c.border = _std()
        c.number_format = fmt

    ws.cell(row=tr, column=11).fill = _fill(HEADER_BG)
    ws.cell(row=tr, column=11).border = _std()
    ws.row_dimensions[tr].height = 24

    # Holiday calendar
    hr = tr + 2
    ws.cell(row=hr, column=1, value="■ 祝日一覧（対象期間内）").font = _font(10, bold=True, color=HEADER_BG[2:])
    ws.row_dimensions[hr].height = 20

    for col, val in enumerate(["日付", "曜日", "祝日名"], start=1):
        c = ws.cell(row=hr+1, column=col, value=val)
        c.font = _font(9, bold=True, color=HEADER_FG)
        c.fill = _fill(MONTH_BG)
        c.alignment = _align()
        c.border = _std()

    WEEKDAY_JP = ["月","火","水","木","金","土","日"]
    for idx, (hd, hname) in enumerate(sorted(holidays.items())):
        r = hr + 2 + idx
        bg = ROW_EVEN if idx % 2 == 0 else ROW_ODD
        fill = _fill(bg)
        for col, val, h, fmt in [
            (1, hd, "center", "YYYY/MM/DD"),
            (2, WEEKDAY_JP[hd.weekday()], "center", None),
            (3, hname, "left", None),
        ]:
            c = ws.cell(row=r, column=col, value=val)
            c.font = _font(9)
            c.fill = fill
            c.alignment = _align(h=h, indent=1 if h == "left" else 0)
            c.border = _std()
            if fmt:
                c.number_format = fmt
        ws.row_dimensions[r].height = 16

    ws.freeze_panes = "A5"
    ws.sheet_properties.tabColor = "2F5496"


# ==================================================
#  ガントチャートシート
# ==================================================
def create_gantt_sheet(wb: Workbook, title: str, tasks: list[dict],
                       holidays: dict[date, str]) -> None:
    ws = wb.create_sheet("ガントチャート")

    all_starts = [t["start"] for t in tasks]
    all_ends   = [t["end"]   for t in tasks]
    min_date   = min(all_starts).replace(day=1)
    max_date   = max(all_ends) + timedelta(days=5)

    dates = []
    d = min_date
    while d <= max_date:
        dates.append(d)
        d += timedelta(days=1)

    INFO_COLS = 5
    DATE_COL  = INFO_COLS + 1
    MONTH_ROW = 2
    DAY_ROW   = 3
    DOW_ROW   = 4
    DATA_ROW  = 5

    for letter, w in {"A": 4.5, "B": 8, "C": 22, "D": 7, "E": 7}.items():
        ws.column_dimensions[letter].width = w

    # Title
    last_col = get_column_letter(DATE_COL + len(dates) - 1)
    ws.merge_cells(f"A1:{last_col}1")
    c = ws["A1"]
    c.value = title
    c.font = _font(16, bold=True, color=HEADER_FG)
    c.fill = _fill(HEADER_BG)
    c.alignment = _align()
    ws.row_dimensions[1].height = 40

    # Left headers (merged rows 2-4)
    for ci, lbl in enumerate(["No.", "ステータス", "タスク名", "担当者", "進捗"], start=1):
        ws.merge_cells(f"{get_column_letter(ci)}{MONTH_ROW}:{get_column_letter(ci)}{DOW_ROW}")
        c = ws.cell(row=MONTH_ROW, column=ci, value=lbl)
        c.font = _font(8, bold=True, color=HEADER_FG)
        c.fill = _fill(HEADER_BG)
        c.alignment = _align()
        c.border = _std()
        for r in [DAY_ROW, DOW_ROW]:
            ws.cell(row=r, column=ci).fill = _fill(HEADER_BG)
            ws.cell(row=r, column=ci).border = _std()

    ws.row_dimensions[MONTH_ROW].height = 20
    ws.row_dimensions[DAY_ROW].height = 16
    ws.row_dimensions[DOW_ROW].height = 14

    # Month headers
    month_groups: list[tuple[int, int, int, int]] = []
    cur_m = cur_y = cur_sc = None
    for i, d in enumerate(dates):
        col = DATE_COL + i
        if d.month != cur_m:
            if cur_m is not None:
                month_groups.append((cur_m, cur_y, cur_sc, col - 1))
            cur_m, cur_y, cur_sc = d.month, d.year, col
    if cur_m is not None:
        month_groups.append((cur_m, cur_y, cur_sc, DATE_COL + len(dates) - 1))

    MONTH_JP = ["1月","2月","3月","4月","5月","6月",
                "7月","8月","9月","10月","11月","12月"]
    for (month, year, sc, ec) in month_groups:
        if sc != ec:
            ws.merge_cells(f"{get_column_letter(sc)}{MONTH_ROW}:{get_column_letter(ec)}{MONTH_ROW}")
        c = ws.cell(row=MONTH_ROW, column=sc, value=f"{year}年 {MONTH_JP[month-1]}")
        c.font = _font(9, bold=True, color=HEADER_FG)
        c.fill = _fill(MONTH_BG)
        c.alignment = _align()
        c.border = _std()

    # Day & weekday headers
    WEEKDAY_JP = ["月","火","水","木","金","土","日"]
    for i, d in enumerate(dates):
        col = DATE_COL + i
        ws.column_dimensions[get_column_letter(col)].width = 3.0

        is_we  = d.weekday() >= 5
        is_hol = is_holiday(d, holidays)
        is_m1  = d.day == 1

        if is_hol:
            day_bg, day_fg = HOLIDAY_BG, "FFC00000"
            dow_bg, dow_fg = HOLIDAY_BG, "FFC00000"
        elif is_we:
            day_bg, day_fg = WEEKEND_BG, "FF595959"
            dow_bg, dow_fg = WEEKEND_BG, "FF999999"
        else:
            day_bg, day_fg = "FFD9E1F2", HEADER_BG
            dow_bg, dow_fg = "FFE8EDF5", "FF595959"

        l_style = "medium" if is_m1 else "thin"
        l_color = MONTH_LINE if is_m1 else GRIDLINE

        c = ws.cell(row=DAY_ROW, column=col, value=d.day)
        c.font = _font(7, bold=True, color=day_fg)
        c.fill = _fill(day_bg)
        c.alignment = _align()
        c.border = _border(left=l_style, left_c=l_color)

        c = ws.cell(row=DOW_ROW, column=col, value=WEEKDAY_JP[d.weekday()])
        c.font = _font(6, color=dow_fg)
        c.fill = _fill(dow_bg)
        c.alignment = _align()
        c.border = _border(left=l_style, left_c=l_color)

    # Task rows
    for ti, task in enumerate(tasks):
        row = DATA_ROW + ti
        color = TASK_COLORS[ti % len(TASK_COLORS)]
        bg = ROW_EVEN if ti % 2 == 0 else ROW_ODD
        is_ms = task["start"] == task["end"]
        progress = task.get("progress", 0) / 100.0

        ws.row_dimensions[row].height = 24

        # No.
        c = ws.cell(row=row, column=1, value=ti + 1)
        c.font = _font(8, color="FF595959")
        c.fill = _fill(bg)
        c.alignment = _align()
        c.border = _std()

        # Status
        st = task.get("status", "未着手")
        sc = STATUS_COLORS.get(st, STATUS_COLORS["未着手"])
        c = ws.cell(row=row, column=2, value=st)
        c.font = _font(7, bold=True, color=sc["fg"])
        c.fill = _fill(sc["bg"])
        c.alignment = _align()
        c.border = _std()

        # Task name
        c = ws.cell(row=row, column=3, value=task["name"])
        c.font = _font(9, bold=True, color="FF1F3864")
        c.fill = _fill(bg)
        c.alignment = _align(h="left", indent=1)
        c.border = _std()

        # Assignee
        c = ws.cell(row=row, column=4, value=task.get("assignee", ""))
        c.font = _font(8)
        c.fill = _fill(bg)
        c.alignment = _align()
        c.border = _std()

        # Progress %
        c = ws.cell(row=row, column=5, value=f"{int(progress*100)}%")
        if progress >= 1.0:
            c.font = _font(8, bold=True, color="FF375623")
            c.fill = _fill("FFE2EFDA")
        elif progress > 0:
            c.font = _font(8, bold=True, color="FF1F4E79")
            c.fill = _fill("FFDCE6F1")
        else:
            c.font = _font(8, color="FF999999")
            c.fill = _fill(bg)
        c.alignment = _align()
        c.border = _std()

        # Date cells
        t_si = t_ei = None
        for i, d in enumerate(dates):
            if d == task["start"]: t_si = i
            if d == task["end"]:   t_ei = i

        for i, d in enumerate(dates):
            col = DATE_COL + i
            is_we  = d.weekday() >= 5
            is_hol = is_holiday(d, holidays)
            is_m1  = d.day == 1
            in_rng = task["start"] <= d <= task["end"]

            c = ws.cell(row=row, column=col, value="")

            if is_ms and d == task["start"]:
                c.value = "◆"
                c.font = _font(10, bold=True, color=MILESTONE_C)
                c.fill = _fill(bg)
                c.alignment = _align()
            elif in_rng and not is_ms:
                if t_si is not None and t_ei is not None:
                    total = t_ei - t_si + 1
                    prog_cells = math.floor(progress * total)
                    offset = i - t_si
                    c.fill = _fill(color["bar"] if offset < prog_cells else color["light"])
                else:
                    c.fill = _fill(color["bar"])
            else:
                if is_hol:
                    c.fill = _fill(HOLIDAY_BG)
                elif is_we:
                    c.fill = _fill(WEEKEND_BG)
                else:
                    c.fill = _fill(bg)

            l_style = "medium" if is_m1 else None
            l_color = MONTH_LINE if is_m1 else GRIDLINE

            if in_rng and not is_ms:
                l_s = (Side(style="thin", color="FFFFFFFF") if d == task["start"]
                       else Side(style="medium", color=MONTH_LINE) if is_m1
                       else Side(style=None))
                r_s = Side(style="thin", color="FFFFFFFF") if d == task["end"] else Side(style=None)
                c.border = Border(left=l_s, right=r_s,
                                  top=Side(style="thin", color=color["light"]),
                                  bottom=Side(style="thin", color=color["light"]))
            else:
                c.border = _border(left=l_style or "thin", left_c=l_color)

    # Today line
    today = date.today()
    if min_date <= today <= max_date:
        tc = DATE_COL + (today - min_date).days
        for r in [DAY_ROW, DOW_ROW]:
            c = ws.cell(row=r, column=tc)
            c.fill = _fill(TODAY_RED)
            c.font = _font(c.font.size or 7, bold=True, color="FFFFFFFF")
        for ti in range(len(tasks)):
            c = ws.cell(row=DATA_ROW + ti, column=tc)
            c.border = Border(
                left=Side(style="medium", color=TODAY_RED),
                right=Side(style="medium", color=TODAY_RED),
                top=Side(style="thin", color=GRIDLINE),
                bottom=Side(style="thin", color=GRIDLINE),
            )

    # Legend
    lr = DATA_ROW + len(tasks) + 2
    ws.cell(row=lr, column=1, value="凡例").font = _font(9, bold=True, color=HEADER_BG[2:])
    ws.row_dimensions[lr].height = 18

    legend = [
        ("  ", TASK_COLORS[0]["bar"], "進捗済み期間"),
        ("  ", TASK_COLORS[0]["light"], "未進捗期間"),
        ("  ", WEEKEND_BG, "土曜・日曜"),
        ("  ", HOLIDAY_BG, "祝日"),
        ("◆", None, "マイルストーン"),
        ("|",  None, "本日ライン（赤）"),
    ]
    for idx, (sym, clr, desc) in enumerate(legend):
        r = lr + 1 + idx
        if clr:
            c = ws.cell(row=r, column=1, value="  ")
            c.fill = _fill(clr)
            c.border = _std()
        else:
            ws.cell(row=r, column=1, value=sym).font = _font(
                9, bold=True, color="FFFF4444" if sym in ("◆", "|") else "FF333333")
        ws.merge_cells(f"B{r}:C{r}")
        ws.cell(row=r, column=2, value=desc).font = _font(8, color="FF595959")
        ws.row_dimensions[r].height = 15

    # Sheet settings
    ws.freeze_panes = f"{get_column_letter(DATE_COL)}{DATA_ROW}"
    ws.sheet_view.showGridLines = False
    ws.sheet_properties.tabColor = "4472C4"

    # Print settings
    ws.page_setup.orientation = "landscape"
    ws.page_setup.paperSize = ws.PAPERSIZE_A3
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_title_rows = f"{MONTH_ROW}:{DOW_ROW}"
    ws.print_title_cols = f"A:{get_column_letter(INFO_COLS)}"
    for attr in ("left", "right"):
        setattr(ws.page_margins, attr, 0.3)
    for attr in ("top", "bottom"):
        setattr(ws.page_margins, attr, 0.4)


# ==================================================
#  使い方シート
# ==================================================
def create_help_sheet(wb: Workbook) -> None:
    ws = wb.create_sheet("使い方")

    ws.merge_cells("A1:E1")
    c = ws["A1"]
    c.value = "📖  使い方ガイド"
    c.font = _font(16, bold=True, color=HEADER_FG)
    c.fill = _fill(HEADER_BG)
    c.alignment = _align()
    ws.row_dimensions[1].height = 36
    ws.column_dimensions["A"].width = 4
    ws.column_dimensions["B"].width = 65

    content = [
        ("■ クイックスタート", [
            "1. config.json を編集してタスクデータを入力",
            "2. ターミナルで以下を実行:",
            "     pip install openpyxl",
            "     python gantt_chart_generator.py",
            "3. 同じフォルダに「ガントチャート.xlsx」が生成されます",
        ]),
        ("■ コマンドラインオプション", [
            "  python gantt_chart_generator.py                  → config.json を読み込み",
            "  python gantt_chart_generator.py -c project.json  → 設定ファイル指定",
            "  python gantt_chart_generator.py -o result.xlsx   → 出力ファイル名指定",
            "  python gantt_chart_generator.py --sample          → サンプル config.json を生成",
        ]),
        ("■ config.json の書き方", [
            '{',
            '  "title": "プロジェクト名 工程表",',
            '  "tasks": [',
            '    {',
            '      "name": "タスク名",',
            '      "start": "2026-04-01",',
            '      "end": "2026-04-07",',
            '      "assignee": "担当者名",',
            '      "status": "未着手",    // 完了/進行中/未着手/遅延/中断',
            '      "priority": "高",      // 最高/高/中/低',
            '      "progress": 0,         // 0〜100（%）',
            '      "note": "備考"',
            '    }',
            '  ]',
            '}',
        ]),
        ("■ マイルストーン", [
            "開始日と終了日を同じ日にすると ◆ マークで表示されます",
        ]),
        ("■ 色の説明", [
            "濃いバー → 進捗済み ／ 薄いバー → 残作業",
            "薄いグレー → 土日 ／ 薄いピンク → 祝日",
            "赤い縦線 → 本日",
        ]),
        ("■ 祝日について", [
            "2025〜2027年の日本の祝日がスクリプトに内蔵されています",
            "他の年度が必要な場合は HOLIDAYS 辞書に追加してください",
        ]),
        ("■ 印刷", [
            "ガントチャートシートは A3 横向き・縮小印刷対応済み",
        ]),
    ]

    row = 3
    for section, lines in content:
        ws.cell(row=row, column=2, value=section).font = _font(11, bold=True, color=HEADER_BG[2:])
        ws.row_dimensions[row].height = 24
        row += 1
        for line in lines:
            c = ws.cell(row=row, column=2, value=line)
            c.font = _font(9, color="FF333333")
            c.alignment = _align(h="left", indent=1, wrap=True)
            ws.row_dimensions[row].height = 17
            row += 1
        row += 1

    ws.sheet_view.showGridLines = False
    ws.sheet_properties.tabColor = "70AD47"


# ==================================================
#  メイン
# ==================================================
def main() -> None:
    parser = argparse.ArgumentParser(
        description="日本語ガントチャート生成ツール（.xlsx）")
    parser.add_argument("-c", "--config", default="config.json",
                        help="設定ファイルのパス（デフォルト: config.json）")
    parser.add_argument("-o", "--output", default=None,
                        help="出力ファイル名（デフォルト: ガントチャート.xlsx）")
    parser.add_argument("--sample", action="store_true",
                        help="サンプル設定ファイル config.json を生成")
    args = parser.parse_args()

    if args.sample:
        generate_sample_config("config.json")
        return

    config_path = Path(args.config)
    if not config_path.exists():
        print(f"❌ 設定ファイルが見つかりません: {config_path}")
        print(f"   --sample オプションでサンプルを生成できます:")
        print(f"   python {sys.argv[0]} --sample")
        sys.exit(1)

    cfg = load_config(str(config_path))
    tasks = cfg["tasks"]
    title = cfg["title"]
    output = args.output or "ガントチャート.xlsx"

    all_starts = [t["start"] for t in tasks]
    all_ends   = [t["end"]   for t in tasks]
    holidays = get_holidays_for_range(min(all_starts), max(all_ends))

    wb = Workbook()
    create_input_sheet(wb, title, tasks, holidays)
    create_gantt_sheet(wb, title, tasks, holidays)
    create_help_sheet(wb)
    wb.save(output)

    print(f"✅ ガントチャートを生成しました: {output}")
    print(f"   タスク数: {len(tasks)}")
    print(f"   対象祝日: {len(holidays)}日")
    print(f"   シート:   入力 / ガントチャート / 使い方")


if __name__ == "__main__":
    main()
